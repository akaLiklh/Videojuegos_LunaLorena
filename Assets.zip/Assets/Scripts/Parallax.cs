using UnityEngine;

// Mueve una capa de fondo m�s despacio que la c�mara para dar sensaci�n de profundidad.
public class Parallax : MonoBehaviour
{
    // 0 = va pegada a la c�mara (muy lejos, como el cielo).
    // 1 = se mueve como el escenario (muy cerca).
    [Range(0f, 1f)]
    [SerializeField] private float factor = 0.2f;

    private Transform cam;        // la c�mara principal
    private Vector3 camInicio;    // d�nde estaba la c�mara al empezar
    private Vector3 posInicio;    // d�nde estaba esta capa al empezar

    void Start()
    {
        cam = Camera.main.transform;
        camInicio = cam.position;
        posInicio = transform.position;
    }

    // LateUpdate se ejecuta despu�s de que la c�mara se haya movido en ese frame
    void LateUpdate()
    {
        // Cu�nto se ha movido la c�mara desde el principio
        Vector3 desplazamiento = cam.position - camInicio;

        // La capa acompa�a a la c�mara en la parte (1 - factor):
        // con factor 0 parece quieta al fondo,
        // con factor 1 se mueve como el escenario.
        transform.position = new Vector3(
            posInicio.x + desplazamiento.x * (1f - factor),
            posInicio.y + desplazamiento.y * (1f - factor),
            posInicio.z);
    }
}